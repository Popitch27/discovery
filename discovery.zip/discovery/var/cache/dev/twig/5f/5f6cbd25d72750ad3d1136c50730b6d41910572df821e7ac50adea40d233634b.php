<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* blog/home.html.twig */
class __TwigTemplate_7d3f703b82e2fa898e5ba945673354b53b57dc5dbea3936c3c83dc423b06afed extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "blog/home.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "blog/home.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "blog/home.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "<h1>";
        echo twig_escape_filter($this->env, (isset($context["title"]) || array_key_exists("title", $context) ? $context["title"] : (function () { throw new RuntimeError('Variable "title" does not exist.', 4, $this->source); })()), "html", null, true);
        echo "</h1>

    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Asperiores, at ea eius facere, iure magnam maxime optio
        placeat quaerat recusandae sequi sit tempora vero. Adipisci aspernatur assumenda commodi consequatur debitis
        dolore eius enim error esse, ex facilis harum illum ipsam magnam minus molestiae mollitia nemo perferendis
        placeat praesentium quaerat quos reiciendis repellat repudiandae vitae voluptates voluptatibus! Accusamus
        aliquam animi, blanditiis commodi debitis delectus deserunt dolorem ea eaque earum eligendi excepturi, fugiat
        harum illo impedit incidunt laudantium magni minima molestias nesciunt possimus praesentium quaerat quis
        suscipit tenetur vel vero voluptas. Commodi dicta earum expedita molestias mollitia odio quis repellat
        repudiandae sunt.</p><p>Accusantium amet asperiores beatae corporis cum distinctio dolorem ducimus facilis fuga
    hic ipsa ipsam minima modi mollitia, nemo nobis non odit perferendis praesentium provident quae quia quis, quo quod
    soluta suscipit vel voluptatibus? Alias aperiam, autem consequuntur esse, eveniet impedit neque perferendis quam qui
    quibusdam, quod reprehenderit temporibus unde? Accusamus, adipisci blanditiis consectetur consequatur consequuntur
    deserunt distinctio ducimus eligendi eos error est facilis fugiat harum illo illum ipsam iste itaque magni maiores
    minima molestias neque nesciunt nisi nostrum officia optio perferendis, placeat porro rem, rerum sequi similique
    soluta temporibus totam velit vitae voluptatibus! Architecto beatae, est neque reprehenderit veritatis
    voluptatibus.</p><p>Ab accusamus alias dignissimos distinctio dolores earum eos fugit laborum minus, quasi
    repellendus veritatis. Atque deleniti esse id illum iusto, quas ut! Architecto corporis cum cumque eaque, eveniet
    explicabo id modi officiis perferendis quae tenetur vero! Alias asperiores blanditiis dolore dolorem ea eius
    eligendi facilis iure laborum quisquam? Accusantium atque consequuntur culpa cupiditate doloremque eaque, est harum
    natus nesciunt quos ratione recusandae reprehenderit sint sunt tenetur velit voluptas! Earum esse explicabo facilis
    incidunt magni molestiae optio quibusdam quod sit? Animi architecto culpa distinctio eligendi esse et ex
    exercitationem explicabo fugit ipsa laboriosam laudantium quisquam sed sint temporibus tenetur, unde veniam.</p><p>
    Aliquid, blanditiis consectetur dolorum eum illum molestias nam natus neque repudiandae rerum sed similique tempora
    totam? Asperiores consequatur, dolorum error ex illum laboriosam laudantium nihil nulla placeat quos repellat sed
    vel. At dicta eos, facere facilis hic illo ipsa iusto tenetur! Accusamus ad aliquam aliquid commodi consequatur
    cupiditate, deserunt eligendi ex exercitationem hic id illo illum magni modi molestiae nobis nulla odio officiis
    optio perspiciatis porro possimus praesentium quidem rerum similique temporibus totam, voluptatum. Assumenda
    consequatur ducimus eligendi enim inventore iusto, molestias non quae, quaerat quisquam recusandae tempore veritatis
    vero, voluptas voluptate. Dolorem doloribus eligendi error inventore nam, velit voluptatem!</p>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "blog/home.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  68 => 4,  58 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block body %}
<h1>{{ title }}</h1>

    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Asperiores, at ea eius facere, iure magnam maxime optio
        placeat quaerat recusandae sequi sit tempora vero. Adipisci aspernatur assumenda commodi consequatur debitis
        dolore eius enim error esse, ex facilis harum illum ipsam magnam minus molestiae mollitia nemo perferendis
        placeat praesentium quaerat quos reiciendis repellat repudiandae vitae voluptates voluptatibus! Accusamus
        aliquam animi, blanditiis commodi debitis delectus deserunt dolorem ea eaque earum eligendi excepturi, fugiat
        harum illo impedit incidunt laudantium magni minima molestias nesciunt possimus praesentium quaerat quis
        suscipit tenetur vel vero voluptas. Commodi dicta earum expedita molestias mollitia odio quis repellat
        repudiandae sunt.</p><p>Accusantium amet asperiores beatae corporis cum distinctio dolorem ducimus facilis fuga
    hic ipsa ipsam minima modi mollitia, nemo nobis non odit perferendis praesentium provident quae quia quis, quo quod
    soluta suscipit vel voluptatibus? Alias aperiam, autem consequuntur esse, eveniet impedit neque perferendis quam qui
    quibusdam, quod reprehenderit temporibus unde? Accusamus, adipisci blanditiis consectetur consequatur consequuntur
    deserunt distinctio ducimus eligendi eos error est facilis fugiat harum illo illum ipsam iste itaque magni maiores
    minima molestias neque nesciunt nisi nostrum officia optio perferendis, placeat porro rem, rerum sequi similique
    soluta temporibus totam velit vitae voluptatibus! Architecto beatae, est neque reprehenderit veritatis
    voluptatibus.</p><p>Ab accusamus alias dignissimos distinctio dolores earum eos fugit laborum minus, quasi
    repellendus veritatis. Atque deleniti esse id illum iusto, quas ut! Architecto corporis cum cumque eaque, eveniet
    explicabo id modi officiis perferendis quae tenetur vero! Alias asperiores blanditiis dolore dolorem ea eius
    eligendi facilis iure laborum quisquam? Accusantium atque consequuntur culpa cupiditate doloremque eaque, est harum
    natus nesciunt quos ratione recusandae reprehenderit sint sunt tenetur velit voluptas! Earum esse explicabo facilis
    incidunt magni molestiae optio quibusdam quod sit? Animi architecto culpa distinctio eligendi esse et ex
    exercitationem explicabo fugit ipsa laboriosam laudantium quisquam sed sint temporibus tenetur, unde veniam.</p><p>
    Aliquid, blanditiis consectetur dolorum eum illum molestias nam natus neque repudiandae rerum sed similique tempora
    totam? Asperiores consequatur, dolorum error ex illum laboriosam laudantium nihil nulla placeat quos repellat sed
    vel. At dicta eos, facere facilis hic illo ipsa iusto tenetur! Accusamus ad aliquam aliquid commodi consequatur
    cupiditate, deserunt eligendi ex exercitationem hic id illo illum magni modi molestiae nobis nulla odio officiis
    optio perspiciatis porro possimus praesentium quidem rerum similique temporibus totam, voluptatum. Assumenda
    consequatur ducimus eligendi enim inventore iusto, molestias non quae, quaerat quisquam recusandae tempore veritatis
    vero, voluptas voluptate. Dolorem doloribus eligendi error inventore nam, velit voluptatem!</p>
{% endblock %}

", "blog/home.html.twig", "/home/animateur/Documents/symfony/discovery/templates/blog/home.html.twig");
    }
}
