<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* blog/test.html.twig */
class __TwigTemplate_99c4915bd7866ecb62e32005f607b64a5e1cf1e8cd8b26e91e08b4e5cb1fb2d5 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "blog/test.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "blog/test.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "blog/test.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 2
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "    <h1>Ceci est un test!!</h1>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium cumque cupiditate debitis deserunt dolorem
        enim, eos explicabo illo molestias nemo nisi nulla officia quae similique tempore unde veniam! Accusantium animi
        dolore ea labore velit. Amet blanditiis cupiditate delectus esse hic id nisi, quis vitae! Asperiores doloremque
        facilis in qui, saepe veniam voluptate? Assumenda atque cumque delectus distinctio dolore dolores, eum illum
        impedit iure maxime mollitia nihil praesentium provident, quas quibusdam quisquam reiciendis rerum sapiente unde
        voluptates! Accusantium ad corporis, explicabo in iusto, maxime numquam pariatur provident quam qui quos sequi
        veniam vero. Ab beatae consequatur delectus eius est, et ex exercitationem id ipsam itaque non officia qui quos
        repellendus repudiandae sit vitae voluptate. Accusantium at delectus doloribus eaque ex fugit harum impedit
        incidunt ipsam laudantium magnam maiores modi mollitia, nemo non nulla numquam possimus provident quas quia quod
        ratione reprehenderit rerum saepe sed similique tempora ut. Assumenda, aut blanditiis dicta dignissimos dolorum
        facilis impedit iste labore nihil nostrum possimus quibusdam quisquam quod quos recusandae totam voluptas? At
        aut impedit iure labore nobis obcaecati odit quam quibusdam sequi unde! Assumenda corporis eveniet fugiat, fugit
        mollitia provident, quae quibusdam quos sed similique sunt unde vel vero. Ad dicta error minima recusandae
        vel.</p>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "blog/test.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  68 => 3,  58 => 2,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}
{% block body %}
    <h1>Ceci est un test!!</h1>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium cumque cupiditate debitis deserunt dolorem
        enim, eos explicabo illo molestias nemo nisi nulla officia quae similique tempore unde veniam! Accusantium animi
        dolore ea labore velit. Amet blanditiis cupiditate delectus esse hic id nisi, quis vitae! Asperiores doloremque
        facilis in qui, saepe veniam voluptate? Assumenda atque cumque delectus distinctio dolore dolores, eum illum
        impedit iure maxime mollitia nihil praesentium provident, quas quibusdam quisquam reiciendis rerum sapiente unde
        voluptates! Accusantium ad corporis, explicabo in iusto, maxime numquam pariatur provident quam qui quos sequi
        veniam vero. Ab beatae consequatur delectus eius est, et ex exercitationem id ipsam itaque non officia qui quos
        repellendus repudiandae sit vitae voluptate. Accusantium at delectus doloribus eaque ex fugit harum impedit
        incidunt ipsam laudantium magnam maiores modi mollitia, nemo non nulla numquam possimus provident quas quia quod
        ratione reprehenderit rerum saepe sed similique tempora ut. Assumenda, aut blanditiis dicta dignissimos dolorum
        facilis impedit iste labore nihil nostrum possimus quibusdam quisquam quod quos recusandae totam voluptas? At
        aut impedit iure labore nobis obcaecati odit quam quibusdam sequi unde! Assumenda corporis eveniet fugiat, fugit
        mollitia provident, quae quibusdam quos sed similique sunt unde vel vero. Ad dicta error minima recusandae
        vel.</p>
{% endblock %}", "blog/test.html.twig", "/home/animateur/Documents/symfony/discovery/templates/blog/test.html.twig");
    }
}
