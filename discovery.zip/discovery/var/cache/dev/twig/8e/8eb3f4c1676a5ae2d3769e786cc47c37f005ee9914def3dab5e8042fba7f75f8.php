<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* blog/home.html.twig */
class __TwigTemplate_c9feede9f7adf474b9898d3fe977729002ba326134497cee5de5c281df17f66c extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "blog/home.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "blog/home.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "blog/home.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "<h1>";
        echo twig_escape_filter($this->env, (isset($context["title"]) || array_key_exists("title", $context) ? $context["title"] : (function () { throw new RuntimeError('Variable "title" does not exist.', 4, $this->source); })()), "html", null, true);
        echo "</h1>

    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Consequatur dignissimos eius id impedit maiores
        necessitatibus pariatur porro, vitae! Accusantium adipisci, alias amet asperiores atque autem commodi
        consequuntur cupiditate, debitis dolore dolorum ducimus ea est eum ex ipsum laudantium, magni minus molestias
        nam nesciunt nihil numquam pariatur quaerat quia quis reiciendis rem reprehenderit saepe sequi suscipit tempore
        totam vel veniam veritatis vero voluptatum. Beatae blanditiis cum deleniti earum nesciunt, perspiciatis tempore?
        Accusamus at consequuntur corporis deleniti eius eligendi eos et eveniet fugiat ipsum iusto libero magnam, magni
        nisi nobis nostrum obcaecati quae quas quibusdam sed similique soluta tempore tenetur, vel voluptatibus?</p><p>
    Alias aperiam asperiores atque commodi consequuntur corporis culpa deleniti dolore dolorem doloribus eius eligendi
    enim error eveniet fugiat impedit in iste libero magnam magni maiores minima, molestias mollitia non nostrum nulla,
    odit pariatur quaerat quia quibusdam reprehenderit rerum sed sit totam ut, vero voluptas. Aspernatur aut dolorem
    enim est eum ex fuga fugiat illum in ipsa iste iure laboriosam nihil nostrum, omnis, quasi reiciendis saepe
    similique sit velit. Amet blanditiis facere iure provident quia quibusdam reprehenderit, veritatis vitae voluptas!
    Aliquam architecto deserunt doloribus, ea earum, eveniet ex, fuga incidunt iste laboriosam molestiae quae similique
    voluptatibus? Alias esse ipsum minus nam.</p><p>Autem dolore dolorum eligendi enim labore nihil perferendis rerum.
    Accusamus, aliquam amet architecto blanditiis cumque facilis nesciunt nisi odio perferendis possimus reiciendis
    repellendus, temporibus! Cupiditate, facilis impedit in labore mollitia numquam reprehenderit repudiandae sunt
    tempore. Aperiam aut consequuntur corporis dicta dolorem esse illum impedit in minus modi necessitatibus nisi, odio,
    optio quod sint sit tempore tenetur ullam veritatis voluptatum. Adipisci consectetur deserunt dignissimos dolorum
    ducimus eligendi eos, excepturi, illum ipsa perferendis quia reiciendis sed soluta ullam voluptates! A aliquam
    aspernatur consequuntur dolores ducimus ex facilis iure maiores nemo officia quibusdam reiciendis reprehenderit
    rerum sapiente, voluptatem. Asperiores cupiditate quasi quo! Nesciunt.</p><p>At dicta dolores eum, harum illum
    laborum libero minima, nihil non rem sed unde voluptates? Aperiam cumque eaque facilis fugit maxime quae quidem quis
    veritatis vero voluptatem. Architecto autem blanditiis consequuntur, ea earum est eum illo iste, laudantium officiis
    placeat repellendus repudiandae sit veniam voluptatibus. A aliquid consequatur debitis esse illo in ipsum labore
    quae repellat ut? A accusamus ad alias aliquam asperiores autem consequatur cum cumque cupiditate dicta dolor
    doloremque earum eius expedita, facere fugiat in ipsum itaque libero minima nisi obcaecati officiis perspiciatis
    possimus quaerat, quidem quisquam quod quos rem saepe soluta tempora tenetur velit vitae voluptatem voluptatum!</p>
    <p>Aliquam aliquid autem beatae cum dolore dolores ducimus enim eveniet expedita, explicabo harum iste nam nostrum
        obcaecati omnis optio perspiciatis quaerat quia unde voluptatem. Adipisci deleniti, et minima nihil nisi
        possimus quisquam quos repellat soluta. Aspernatur, magnam, obcaecati. Consectetur consequatur deserunt dolore
        eaque et eum, ex fuga inventore ipsum, iure laborum minus natus nemo nesciunt non optio quam quidem quo
        recusandae reiciendis repellat reprehenderit sit suscipit totam vero voluptate voluptatum. Ad distinctio eaque
        est et expedita laborum molestias non nulla, praesentium repudiandae rerum sequi velit vitae? Blanditiis culpa
        cum, cumque error magnam modi molestias natus nulla officia quae qui voluptatum.</p>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "blog/home.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  68 => 4,  58 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block body %}
<h1>{{ title }}</h1>

    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Consequatur dignissimos eius id impedit maiores
        necessitatibus pariatur porro, vitae! Accusantium adipisci, alias amet asperiores atque autem commodi
        consequuntur cupiditate, debitis dolore dolorum ducimus ea est eum ex ipsum laudantium, magni minus molestias
        nam nesciunt nihil numquam pariatur quaerat quia quis reiciendis rem reprehenderit saepe sequi suscipit tempore
        totam vel veniam veritatis vero voluptatum. Beatae blanditiis cum deleniti earum nesciunt, perspiciatis tempore?
        Accusamus at consequuntur corporis deleniti eius eligendi eos et eveniet fugiat ipsum iusto libero magnam, magni
        nisi nobis nostrum obcaecati quae quas quibusdam sed similique soluta tempore tenetur, vel voluptatibus?</p><p>
    Alias aperiam asperiores atque commodi consequuntur corporis culpa deleniti dolore dolorem doloribus eius eligendi
    enim error eveniet fugiat impedit in iste libero magnam magni maiores minima, molestias mollitia non nostrum nulla,
    odit pariatur quaerat quia quibusdam reprehenderit rerum sed sit totam ut, vero voluptas. Aspernatur aut dolorem
    enim est eum ex fuga fugiat illum in ipsa iste iure laboriosam nihil nostrum, omnis, quasi reiciendis saepe
    similique sit velit. Amet blanditiis facere iure provident quia quibusdam reprehenderit, veritatis vitae voluptas!
    Aliquam architecto deserunt doloribus, ea earum, eveniet ex, fuga incidunt iste laboriosam molestiae quae similique
    voluptatibus? Alias esse ipsum minus nam.</p><p>Autem dolore dolorum eligendi enim labore nihil perferendis rerum.
    Accusamus, aliquam amet architecto blanditiis cumque facilis nesciunt nisi odio perferendis possimus reiciendis
    repellendus, temporibus! Cupiditate, facilis impedit in labore mollitia numquam reprehenderit repudiandae sunt
    tempore. Aperiam aut consequuntur corporis dicta dolorem esse illum impedit in minus modi necessitatibus nisi, odio,
    optio quod sint sit tempore tenetur ullam veritatis voluptatum. Adipisci consectetur deserunt dignissimos dolorum
    ducimus eligendi eos, excepturi, illum ipsa perferendis quia reiciendis sed soluta ullam voluptates! A aliquam
    aspernatur consequuntur dolores ducimus ex facilis iure maiores nemo officia quibusdam reiciendis reprehenderit
    rerum sapiente, voluptatem. Asperiores cupiditate quasi quo! Nesciunt.</p><p>At dicta dolores eum, harum illum
    laborum libero minima, nihil non rem sed unde voluptates? Aperiam cumque eaque facilis fugit maxime quae quidem quis
    veritatis vero voluptatem. Architecto autem blanditiis consequuntur, ea earum est eum illo iste, laudantium officiis
    placeat repellendus repudiandae sit veniam voluptatibus. A aliquid consequatur debitis esse illo in ipsum labore
    quae repellat ut? A accusamus ad alias aliquam asperiores autem consequatur cum cumque cupiditate dicta dolor
    doloremque earum eius expedita, facere fugiat in ipsum itaque libero minima nisi obcaecati officiis perspiciatis
    possimus quaerat, quidem quisquam quod quos rem saepe soluta tempora tenetur velit vitae voluptatem voluptatum!</p>
    <p>Aliquam aliquid autem beatae cum dolore dolores ducimus enim eveniet expedita, explicabo harum iste nam nostrum
        obcaecati omnis optio perspiciatis quaerat quia unde voluptatem. Adipisci deleniti, et minima nihil nisi
        possimus quisquam quos repellat soluta. Aspernatur, magnam, obcaecati. Consectetur consequatur deserunt dolore
        eaque et eum, ex fuga inventore ipsum, iure laborum minus natus nemo nesciunt non optio quam quidem quo
        recusandae reiciendis repellat reprehenderit sit suscipit totam vero voluptate voluptatum. Ad distinctio eaque
        est et expedita laborum molestias non nulla, praesentium repudiandae rerum sequi velit vitae? Blanditiis culpa
        cum, cumque error magnam modi molestias natus nulla officia quae qui voluptatum.</p>
{% endblock %}

", "blog/home.html.twig", "/home/mathieu/Documents/discovery/templates/blog/home.html.twig");
    }
}
